<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $session->title }} - Zoom</title>

    <link rel="stylesheet" href="https://source.zoom.us/3.8.10/css/bootstrap.css">
    <link rel="stylesheet" href="https://source.zoom.us/3.8.10/css/react-select.css">

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        body.meeting-active {
            background: #000;
            overflow: hidden;
            padding: 0 !important;
            margin: 0 !important;
        }

        .join-card {
            background: white;
            border-radius: 16px;
            padding: 40px;
            max-width: 450px;
            width: 90%;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            transition: opacity 0.3s ease;
        }

        .join-card.hidden {
            display: none !important;
        }

        .logo {
            width: 60px;
            height: 60px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, #2d8cff 0%, #1a5fff 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        h1 {
            font-size: 24px;
            font-weight: 800;
            color: #1a202c;
            text-align: center;
            margin-bottom: 8px;
        }

        .info {
            text-align: center;
            color: #718096;
            font-size: 14px;
            margin-bottom: 24px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 8px;
            font-size: 14px;
        }

        input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 15px;
            transition: border 0.2s;
        }

        input:focus {
            outline: none;
            border-color: #3182ce;
        }

        button, #join-btn {
            width: 100% !important;
            padding: 14px !important;
            background: linear-gradient(135deg, #3182ce 0%, #2c5aa0 100%) !important;
            color: white !important;
            border: none !important;
            border-radius: 8px !important;
            font-size: 16px !important;
            font-weight: 700 !important;
            cursor: pointer !important;
            transition: transform 0.2s !important;
            display: block !important;
            margin-top: 20px !important;
            visibility: visible !important;
            opacity: 1 !important;
        }

        button:hover:not(:disabled) {
            transform: translateY(-2px);
        }

        button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 16px;
            color: #718096;
            text-decoration: none;
            font-size: 14px;
        }

        .back-link:hover {
            color: #2d3748;
        }

        #zoom-meeting-container {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: 9999;
            background: #000;
        }

        #zoom-meeting-container.active {
            display: block !important;
        }

        /* Hide join card when meeting is active */
        body.meeting-active .join-card {
            display: none !important;
        }

        body.meeting-active .loading {
            display: none !important;
        }

        /* Simple Zoom display - let Zoom SDK handle everything */
        #zmmtg-root {
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            width: 100vw !important;
            height: 100vh !important;
            z-index: 9999 !important;
        }

        /* Hide our UI when Zoom is showing */
        body.zoom-active {
            overflow: hidden;
        }

        body.zoom-active .join-card,
        body.zoom-active .loading {
            display: none !important;
        }

        .loading {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.9);
            display: none;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            z-index: 9998;
        }

        .loading.active {
            display: flex;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 4px solid rgba(255,255,255,0.2);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }

        .loading-text {
            color: white;
            font-size: 16px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* CRITICAL: Force button to be visible */
        form button[type="submit"],
        button[type="submit"]#join-btn,
        .join-card button {
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
            position: relative !important;
            z-index: 100 !important;
        }
    </style>
</head>
<body>

    <div class="join-card" id="join-screen">
        <div class="logo">
            <svg width="32" height="32" viewBox="0 0 90 20" fill="white">
                <path d="M4.94506 20L3.95604 19.95C2.31347 19.8406 1.13603 18.6476 1.03846 16.9991L0.989011 16L12.8571 4H3.95604L2.96583 3.95C1.34815 3.85556 0.177592 2.62595 0.0494498 0.999056L0 7.42403e-06L14.8352 0.000912409L15.8241 0.0499992C17.4625 0.137543 18.6634 1.34167 18.7418 3.00124L18.7912 4L6.92308 16H15.8242L16.8132 16.05C18.4453 16.1531 19.5984 17.3544 19.7308 19.0009L19.7802 20H4.94506Z"/>
            </svg>
        </div>

        <h1>{{ $session->title }}</h1>
        <div class="info">Meeting ID: {{ $session->zoom_meeting_id }}</div>

        <form id="join-form">
            <div class="form-group">
                <label for="display-name">الاسم</label>
                <input type="text" id="display-name" placeholder="أدخل اسمك" value="{{ auth()->user()->name ?? '' }}" required autofocus>
            </div>
            <button type="submit" id="join-btn">الانضمام الآن</button>
        </form>

        <a href="{{ route('admin.sessions.show', $session) }}" class="back-link">← العودة</a>
    </div>

    <div class="loading" id="loading">
        <div class="spinner"></div>
        <div class="loading-text">جاري الاتصال بالاجتماع...</div>
    </div>

    <div id="zoom-meeting-container"></div>

    <script src="https://source.zoom.us/3.8.10/lib/vendor/react.min.js"></script>
    <script src="https://source.zoom.us/3.8.10/lib/vendor/react-dom.min.js"></script>
    <script src="https://source.zoom.us/3.8.10/lib/vendor/redux.min.js"></script>
    <script src="https://source.zoom.us/3.8.10/lib/vendor/redux-thunk.min.js"></script>
    <script src="https://source.zoom.us/3.8.10/lib/vendor/lodash.min.js"></script>
    <script src="https://source.zoom.us/zoom-meeting-3.8.10.min.js"></script>

    <script>
        // Catch any JavaScript errors
        window.onerror = function(msg, url, lineNo, columnNo, error) {
            console.error('JavaScript Error:', {
                message: msg,
                url: url,
                line: lineNo,
                column: columnNo,
                error: error
            });
            alert('خطأ في JavaScript: ' + msg);
            return false;
        };
    </script>

    <script>
        // Wait for DOM to be fully loaded
        document.addEventListener('DOMContentLoaded', function() {
            console.log('📄 DOM fully loaded');
            initializeZoom();
        });

        function initializeZoom() {
            const config = {
                meetingNumber: '{{ $session->zoom_meeting_id }}',
                password: '{{ $session->zoom_password ?? "" }}',
                userName: '{{ auth()->user()->name ?? "" }}',
                userEmail: '{{ auth()->user()->email ?? "" }}',
                leaveUrl: '{{ route("admin.sessions.show", $session) }}',
                role: 1
            };

            console.log('🚀 Page loaded, initializing Zoom SDK...');
        console.log('Config:', {
            meetingNumber: config.meetingNumber,
            hasPassword: !!config.password,
            userName: config.userName
        });

        // Check if Zoom SDK is loaded
        if (typeof ZoomMtg === 'undefined') {
            console.error('❌ Zoom SDK not loaded!');
            alert('خطأ: لم يتم تحميل Zoom SDK. يرجى إعادة تحميل الصفحة.');
        } else {
            console.log('✅ Zoom SDK loaded successfully');
        }

        ZoomMtg.setZoomJSLib('https://source.zoom.us/3.8.10/lib', '/av');
        ZoomMtg.preLoadWasm();
        ZoomMtg.prepareWebSDK();
        ZoomMtg.i18n.load('en-US');
        ZoomMtg.i18n.reload('en-US');

        const joinScreen = document.getElementById('join-screen');
        const joinForm = document.getElementById('join-form');
        const joinBtn = document.getElementById('join-btn');
        const displayName = document.getElementById('display-name');
        const loading = document.getElementById('loading');
        const meetingContainer = document.getElementById('zoom-meeting-container');

        // Pre-fill display name if user is logged in
        if (config.userName && !displayName.value) {
            displayName.value = config.userName;
        }

        console.log('✅ Event listener attached to join form');

        joinForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log('🎯 Join button clicked!');

            const name = displayName.value.trim();
            if (!name) {
                alert('يرجى إدخال اسمك');
                return;
            }

            config.userName = name;
            joinBtn.disabled = true;
            joinBtn.textContent = 'جاري الانضمام...';

            try {
                console.log('📤 Sending signature request...');
                console.log('Meeting Number:', config.meetingNumber);
                console.log('Role:', config.role);

                const csrfToken = document.querySelector('meta[name="csrf-token"]');
                if (!csrfToken) {
                    throw new Error('CSRF token not found');
                }

                const response = await fetch('/admin/zoom/generate-signature', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken.content,
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({
                        meeting_number: config.meetingNumber,
                        role: config.role
                    })
                });

                console.log('📥 Response status:', response.status);

                if (!response.ok) {
                    const errorText = await response.text();
                    console.error('Server error:', errorText);
                    throw new Error(`Server returned ${response.status}: ${errorText}`);
                }

                const data = await response.json();
                console.log('📦 Response data:', data);

                if (!data.success) {
                    throw new Error(data.message || 'فشل الحصول على التوقيع');
                }

                joinScreen.classList.add('hidden');
                loading.classList.add('active');

                console.log('Initializing Zoom SDK...');

                ZoomMtg.init({
                    leaveUrl: config.leaveUrl,
                    patchJsMedia: true,
                    leaveOnPageUnload: true,
                    isSupportAV: true,
                    success: function() {
                        console.log('✅ SDK initialized successfully, joining meeting...');

                        // Check if zmmtg-root exists already
                        const existingRoot = document.getElementById('zmmtg-root');
                        console.log('🔍 Before join - #zmmtg-root exists?', !!existingRoot);
                        if (existingRoot) {
                            console.log('   Display:', window.getComputedStyle(existingRoot).display);
                            console.log('   Visibility:', window.getComputedStyle(existingRoot).visibility);
                        }

                        console.log('🔄 Calling ZoomMtg.join() with:', {
                            meetingNumber: config.meetingNumber,
                            userName: config.userName,
                            hasSignature: !!data.signature,
                            hasPassword: !!config.password
                        });

                        // Simply hide our UI after a delay - let Zoom SDK show itself
                        setTimeout(() => {
                            loading.classList.remove('active');
                            joinScreen.style.display = 'none';
                            document.body.classList.add('zoom-active');
                            console.log('✅ Our UI hidden - Zoom should be visible now');
                        }, 2000); // Wait 2 seconds for Zoom to render

                        ZoomMtg.join({
                            signature: data.signature,
                            sdkKey: '{{ config("services.zoom.sdk_key") }}',
                            meetingNumber: config.meetingNumber,
                            userName: config.userName,
                            userEmail: config.userEmail,
                            passWord: config.password,
                            tk: '',

                            success: function(res) {
                                console.log('✅ Join meeting success callback fired!', res);
                            },

                            error: function(error) {
                                console.error('❌ Join error:', error);
                                alert('فشل الانضمام للاجتماع: ' + (error.errorMessage || error.reason || 'خطأ غير معروف'));
                                reset();
                            }
                        });
                    },

                    error: function(error) {
                        console.error('❌ Init error:', error);
                        alert('خطأ في تهيئة Zoom SDK: ' + (error.errorMessage || error.reason || 'خطأ غير معروف'));
                        reset();
                    }
                });

            } catch (error) {
                console.error('Error:', error);
                alert('حدث خطأ: ' + error.message);
                reset();
            }
        });

            function reset() {
                loading.classList.remove('active');
                joinScreen.classList.remove('hidden');
                joinBtn.disabled = false;
                joinBtn.textContent = 'الانضمام الآن';
                document.body.classList.remove('meeting-active');
                meetingContainer.classList.remove('active');
            }
        } // End of initializeZoom function
    </script>
</body>
</html>
